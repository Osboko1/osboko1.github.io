"use client"

import  from "../components/project-card"

export default function SyntheticV0PageForDeployment() {
  return < />
}